<?php

    session_start();
    include('facebook-connect.php');
    
?>

<html>
    <head>					
        <title>
            
        </title>
        <link href="bootstrap/css/bootstrap.css" rel="stylesheet" />
        <script type="text/javascript" src="js/jquery-1.9.0.min.js"> </script>
        <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"> </script>

        <script type="text/javascript">
            
            var fbConnected = <?php echo isFBConnected(); ?>;			var w = 200;			var h = 200;			var left = Number((screen.width/2)-(w/2));			var tops = Number((screen.height/2)-(h/2));
            if (fbConnected) {
                titleString = "Choose a Facebook friend";
            }
            else {
                titleString = "Connect to Facebook";
            }
            
            $(document).ready(function() {
                $("#fbconnect").tooltip({placement: "right", trigger: "hover", title: titleString});
                if (fbConnected) {
                    $("#fbconnect-link").attr("href", "#");
                }
                });
            
            function fbConnect() {
                if (fbConnected) {
                    // open friend selector
                    return false;
                }
                else {
                    return false;
                }
            }				
            
        </script>

        <style type="text/css">
            .container {
                margin-top:50px;
                border: solid 1px #eee;
                border-radius:25px;
                -moz-border-radius:25px; /* Old Firefox */
            }
            .recipient-input, .occasion-select {
                width: 259px;
                /*padding: 0;
                margin: 0;
                height: 20px;*/
                -moz-box-sizing: border-box;
                -webkit-box-sizing: border-box;
                box-sizing: border-box;
            }
            
            .recipient-input {
                width:230px;
                
            }			   
        </style>				
    </head>
    <body>
       <div class="container">
            <div class="row">
                <div class="span9">
                     <img src="img/Aprogift L.png" />
                </div>
                <div class="span2">
                    <table>
                        <tbody>
                            <tr>
                                <td>
                                    &nbsp;
                                </td>
                            </tr>
                            <tr>
                                <td>																	<a href="javascript:window.open('img/logo_white.jpg', '', 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width='+w+', height='+h+', top='+tops+', left='+left);">How it works</a>									
																		
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="span1">
                    <table>
                        <tbody>
                            <tr>
                                <td>
                                    &nbsp;
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <a href="javascript:window.open('http://www.aprogift.com/faqs','mywindow','width=1200,height=900')">FAQs</a>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <hr style="margin-top: 0px" />
            <div class="row pagination-centered">
                <div class="span12">
                     <img src="img/s 1.png" />
                </div>
            </div>
            <br />
            <div class="row pagination-centered">
                <div class="span6">
                    <table class="" align="center" width=100%>
                        <tbody>
                            <tr>
                                <td style="text-align:center;">
                                    <img src="img/item.jpg" class="img-polaroid" />
                                </td>
                                <td>
                                     Dell Laptop
                                </td>
                            </tr>
                            <tr>
                                <td style="padding-top:20px; padding-bottom:20px; text-align:center;">
                                     Total Price
                                </td>
                                <td>
                                     Rs. 25000
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <br/>
                    <div style="margin-bottom:10px;">
                    </div>
                </div>
                <div class="span6">
                    <form action="page2.php">
                        <div class="control-group">
                            <label> Who is the gift for? </label>
                            <div class="input-prepend input-append">
                                <input style="height:30px" placeholder="Recipient's Name" class="recipient-input" id="appendedPrependedInput" type="text" name="recipient">
                                <span class="add-on" style="padding: 0px">
                                    <a href="facebook-auth.php" id="fbconnect-link" onClick="fbConnect()">
                                        <img id="fbconnect" style="height:29px; width:29px" src="img/facebook_icon_small.jpg" />
                                    </a>
                                </span> 
                            </div>
                            <!-- Modal -->
                            <!--
                            <div id="myModal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                    <h4> Connect to Facebook </h4>
                                </div>
                                <div class="modal-body">
                                </div>
                                <div class="modal-footer">
                                    <button class="btn btn-primary" data-dismiss="modal">Select</button>
                                </div>
                            </div>
                            -->    
                        </div>
                        <div class="control-group">  
                            <label class="control-label" for="occassion">Any particular occassion?</label>  
                            <div class="controls">  
                                <select id="occassion" class="occasion-select">  
                                    <option>Birthday</option>  
                                    <option>Anniversary</option>
                                    <option>Graduation</option>  
                                    <option>Farewell</option>																		<option>Job Promotion</option>																		<option>Valentine's</option>
                                    <option>Date</option>
                                    <option>Wedding</option>  
                                    <option>House Warming</option>																		<option>Just felt like gifting!</option>															
                                </select>  
                            </div>  
                        </div>
                        <br />
                        <div style="text-align:right; padding-right:10px; margin-top:148px;">
                            <table class="" align="right">
                                <tbody>
                                    <tr>
                                        <td>
                                            <button type="submit" class="btn-link">
                                                <img src="img/invite.png" />
                                            </a>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </form>
                </div>
            </div>        
    </body>
</html>